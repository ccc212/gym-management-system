/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type NoshowDTO = {
    cost?: number;
    date?: string;
    handler?: string;
    id?: number;
    notifyUser?: boolean;
    numberOfPeople?: number;
    penalty?: number;
    reason?: string;
    reservationId?: number;
    restrictDays?: number;
    status?: string;
    timeRange?: string;
    userId?: number;
    userName?: string;
    userPhone?: string;
    venueId?: number;
    venueName?: string;
    venueType?: string;
};

