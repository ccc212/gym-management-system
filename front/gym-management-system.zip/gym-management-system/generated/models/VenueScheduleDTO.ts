/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type VenueScheduleDTO = {
    bookedBy?: string;
    date?: string;
    numberOfPeople?: number;
    remarks?: string;
    status?: string;
    timeSlot?: string;
    type?: string;
    venueId?: number;
    venueName?: string;
};

