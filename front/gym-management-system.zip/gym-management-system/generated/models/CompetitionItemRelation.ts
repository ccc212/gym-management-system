/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CompetitionItemRelation = {
    competitionId?: number;
    competitionItemId?: number;
    id?: number;
};

