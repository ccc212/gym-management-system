/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionDetailVO } from './CompetitionDetailVO';
export type Result_CompetitionDetailVO_ = {
    code?: number;
    data?: CompetitionDetailVO;
    msg?: string;
};

