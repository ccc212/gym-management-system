/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Menu = {
    children?: Array<Menu>;
    code?: string;
    createTime?: string;
    icon?: string;
    id?: number;
    label?: string;
    name?: string;
    orderNum?: string;
    parentId?: number;
    parentName?: string;
    path?: string;
    title?: string;
    type?: string;
    updateTime?: string;
    url?: string;
    value?: number;
};

