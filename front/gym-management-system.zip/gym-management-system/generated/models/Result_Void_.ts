/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Result_Void_ = {
    code?: number;
    msg?: string;
};

