/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UpdateCompetitionItemDTO = {
    category?: number;
    id?: number;
    isTeamCompetition?: number;
    name?: string;
    type?: number;
};

