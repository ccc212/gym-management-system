/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type EquipmentRepair = {
    applyTime?: string;
    equipmentId?: number;
    id?: number;
    reason?: string;
};

