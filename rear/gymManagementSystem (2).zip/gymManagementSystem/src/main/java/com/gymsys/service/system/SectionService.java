package com.gymsys.service.system;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gymsys.entity.system.Section;

public interface SectionService extends IService<Section> {
}
