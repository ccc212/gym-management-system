package com.gymsys.entity.system;

import lombok.Data;

@Data
public class LoginParm {
    private String userNumber;
    private String password;
}
