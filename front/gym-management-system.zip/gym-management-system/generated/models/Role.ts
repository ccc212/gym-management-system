/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Role = {
    createTime?: string;
    id?: number;
    remark?: string;
    roleName?: string;
    type?: string;
    updateTime?: string;
};

