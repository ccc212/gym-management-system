/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type SpecialArrangementDTO = {
    date?: string;
    endTime?: string;
    id?: number;
    remarks?: string;
    startTime?: string;
    status?: string;
    venueId?: number;
};

