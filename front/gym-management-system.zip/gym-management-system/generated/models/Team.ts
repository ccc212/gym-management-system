/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Team = {
    createTime?: string;
    departId?: number;
    id?: number;
    leaderName?: string;
    leaderPhone?: string;
    teamName?: string;
    updateTime?: string;
};

