/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UpdateCompetitionSignUpUserDTO = {
    competitionId?: number;
    competitionItemId?: number;
    departId?: number;
    email?: string;
    id?: number;
    name?: string;
    phone?: string;
    rejectReason?: string;
    remark?: string;
    sex?: string;
    status?: number;
    userId?: number;
    userNumber?: string;
    userStuorfac?: string;
};

