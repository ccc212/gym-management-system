/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ReservationEntity } from './ReservationEntity';
export type Result_ReservationEntity_ = {
    code?: number;
    data?: ReservationEntity;
    msg?: string;
};

