/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionSignUpTeamVO } from './CompetitionSignUpTeamVO';
export type Result_List_CompetitionSignUpTeamVO_ = {
    code?: number;
    data?: Array<CompetitionSignUpTeamVO>;
    msg?: string;
};

