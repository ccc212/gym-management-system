/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TimeSlot = {
    date?: string;
    endTime?: string;
    id?: number;
    price?: number;
    startTime?: string;
    status?: string;
    venueId?: number;
};

