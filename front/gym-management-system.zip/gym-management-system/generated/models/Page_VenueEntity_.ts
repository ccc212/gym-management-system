/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { VenueEntity } from './VenueEntity';
export type Page_VenueEntity_ = {
    current?: number;
    pages?: number;
    records?: Array<VenueEntity>;
    size?: number;
    total?: number;
};

