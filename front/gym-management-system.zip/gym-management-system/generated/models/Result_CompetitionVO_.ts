/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionVO } from './CompetitionVO';
export type Result_CompetitionVO_ = {
    code?: number;
    data?: CompetitionVO;
    msg?: string;
};

