package com.gymsys.constant;

public interface MessageConstant {
    String ADD_SUCCESS = "添加成功";
    String DELETE_SUCCESS = "删除成功";
    String UPDATE_SUCCESS = "修改成功";
}
