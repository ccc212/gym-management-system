/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionEquipmentRelation } from './CompetitionEquipmentRelation';
export type Result_List_CompetitionEquipmentRelation_ = {
    code?: number;
    data?: Array<CompetitionEquipmentRelation>;
    msg?: string;
};

