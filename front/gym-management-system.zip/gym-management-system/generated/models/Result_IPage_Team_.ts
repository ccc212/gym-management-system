/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IPage_Team_ } from './IPage_Team_';
export type Result_IPage_Team_ = {
    code?: number;
    data?: IPage_Team_;
    msg?: string;
};

