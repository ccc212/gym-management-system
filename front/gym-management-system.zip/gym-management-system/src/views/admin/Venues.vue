<template>
    <div class="admin-venues-container">
        <el-card>
            <template #header>
                <div class="card-header">
                    <h2>场地管理</h2>
                    <el-button type="primary" size="small" @click="showAddVenueDialog">添加场地</el-button>
                </div>
            </template>
            
            <!-- 搜索筛选区域 -->
            <el-form :inline="true" class="search-form" size="small">
                <el-form-item label="场地类型">
                    <el-select v-model="searchForm.venueType" placeholder="选择场地类型" clearable @change="searchVenues">
                        <el-option v-for="item in venueTypes" :key="item.value" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="场地状态">
                    <el-select v-model="searchForm.status" placeholder="选择场地状态" clearable @change="searchVenues">
                        <el-option v-for="item in statusOptions" :key="item.value" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="searchVenues">查询</el-button>
                    <el-button @click="resetSearch">重置</el-button>
                </el-form-item>
            </el-form>
            
            <!-- 场地列表 -->
            <el-table 
                v-loading="loading" 
                :data="venueList" 
                style="width: 100%"
                :header-cell-style="{background:'#f5f7fa', color:'#606266'}"
                border>
                <el-table-column prop="id" label="ID" width="60"></el-table-column>
                <el-table-column prop="name" label="场地名称" width="150"></el-table-column>
                <el-table-column prop="type" label="场地类型" width="120"></el-table-column>
                <el-table-column prop="location" label="场地位置"></el-table-column>
                <el-table-column prop="capacity" label="容纳人数" width="100"></el-table-column>
                <el-table-column prop="pricePerHour" label="每小时价格" width="120">
                    <template #default="scope">
                        {{ scope.row.pricePerHour }} 元
                    </template>
                </el-table-column>
                <el-table-column prop="status" label="状态" width="100">
                    <template #default="scope">
                        <el-tag :type="getStatusType(scope.row.status)">{{ getStatusText(scope.row.status) }}</el-tag>
                    </template>
                </el-table-column>
                <el-table-column label="操作" width="220">
                    <template #default="scope">
                        <el-button type="primary" size="small" @click="editVenue(scope.row)">编辑</el-button>
                        <el-button type="danger" size="small" @click="confirmDeleteVenue(scope.row)">删除</el-button>
                        <el-button v-if="scope.row.status === 'NORMAL'" type="warning" size="small" @click="setVenueStatus(scope.row, 'MAINTENANCE')">维护</el-button>
                        <el-button v-if="scope.row.status === 'MAINTENANCE'" type="success" size="small" @click="setVenueStatus(scope.row, 'NORMAL')">恢复</el-button>
                    </template>
                </el-table-column>
            </el-table>
            
            <!-- 分页组件 -->
            <div class="pagination-container">
                <el-pagination
                    @size-change="handleSizeChange"
                    @current-change="handleCurrentChange"
                    :current-page="pagination.currentPage"
                    :page-sizes="[10, 20, 50, 100]"
                    :page-size="pagination.pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="pagination.total">
                </el-pagination>
            </div>
        </el-card>
        
        <!-- 添加/编辑场地弹窗 -->
        <el-dialog :title="dialogType === 'add' ? '添加场地' : '编辑场地'" v-model="venueDialogVisible" width="600px">
            <el-form :model="venueForm" :rules="venueRules" ref="venueFormRef" label-width="100px">
                <el-form-item label="场地名称" prop="name">
                    <el-input v-model="venueForm.name" placeholder="请输入场地名称"></el-input>
                </el-form-item>
                <el-form-item label="场地类型" prop="type">
                    <el-select v-model="venueForm.type" placeholder="请选择场地类型" style="width: 100%">
                        <el-option v-for="item in venueTypeOptions" :key="item.value" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
                <el-form-item label="场地位置" prop="location">
                    <el-input v-model="venueForm.location" placeholder="请输入场地位置"></el-input>
                </el-form-item>
                <el-form-item label="容纳人数" prop="capacity">
                    <el-input-number v-model="venueForm.capacity" :min="1" :max="1000" style="width: 100%"></el-input-number>
                </el-form-item>
                <el-form-item label="每小时价格" prop="pricePerHour">
                    <el-input-number v-model="venueForm.pricePerHour" :min="0" :precision="2" :step="10" style="width: 100%"></el-input-number>
                </el-form-item>
                <el-form-item label="高峰时段价格" prop="peakHourPrice">
                    <el-input-number v-model="venueForm.peakHourPrice" :min="0" :precision="2" :step="10" style="width: 100%"></el-input-number>
                </el-form-item>
                <el-form-item label="设施" prop="facilities">
                    <el-input v-model="venueForm.facilities" type="textarea" placeholder="场地配套设施描述"></el-input>
                </el-form-item>
                <el-form-item label="场地描述" prop="description">
                    <el-input v-model="venueForm.description" type="textarea" placeholder="场地详细描述"></el-input>
                </el-form-item>
                <el-form-item label="场地图片" prop="imageUrl">
                    <el-input v-model="venueForm.imageUrl" placeholder="场地图片URL"></el-input>
                </el-form-item>
                <el-form-item label="场地状态" prop="status">
                    <el-select v-model="venueForm.status" placeholder="请选择场地状态" style="width: 100%">
                        <el-option v-for="item in statusOptions" :key="item.value" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
            <template #footer>
                <span class="dialog-footer">
                    <el-button @click="venueDialogVisible = false">取消</el-button>
                    <el-button type="primary" @click="saveVenue">确定</el-button>
                </span>
            </template>
        </el-dialog>
    </div>
</template>

<script setup lang="ts">
import { ref, reactive, onMounted } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import type { FormInstance } from 'element-plus'
import axios from 'axios'

// 搜索表单
const searchForm = reactive({
    venueType: '',
    status: ''
})

// 场馆类型选项
const venueTypes = [
    { value: '篮球场', label: '篮球场' },
    { value: '足球场', label: '足球场' },
    { value: '羽毛球场', label: '羽毛球场' },
    { value: '网球场', label: '网球场' },
    { value: '游泳池', label: '游泳池' },
    { value: '乒乓球室', label: '乒乓球室' }
]

// 场地状态选项
const statusOptions = [
    { value: 'NORMAL', label: '正常' },
    { value: 'MAINTENANCE', label: '维护中' },
    { value: 'SPECIAL', label: '特殊场地' }
]

// 场馆类型选项（中文）
const venueTypeOptions = [
    { value: '篮球场', label: '篮球场' },
    { value: '足球场', label: '足球场' },
    { value: '羽毛球场', label: '羽毛球场' },
    { value: '网球场', label: '网球场' },
    { value: '游泳池', label: '游泳池' },
    { value: '乒乓球室', label: '乒乓球室' }
]

// 场馆列表
const venueList = ref([])
// 加载状态
const loading = ref(false)
// 分页信息
const pagination = reactive({
    currentPage: 1,
    pageSize: 10,
    total: 0
})
// 场地弹窗可见性
const venueDialogVisible = ref(false)
// 弹窗类型（add/edit）
const dialogType = ref('add')
// 场地表单
const venueForm = reactive({
    id: null,
    name: '',
    type: '',
    location: '',
    capacity: 10,
    pricePerHour: 50,
    peakHourPrice: 80,
    facilities: '',
    description: '',
    imageUrl: '',
    status: 'NORMAL'
})

// 表单验证规则
const venueRules = {
    name: [
        { required: true, message: '请输入场地名称', trigger: 'blur' },
        { min: 2, max: 20, message: '长度在 2 到 20 个字符', trigger: 'blur' }
    ],
    type: [
        { required: true, message: '请选择场地类型', trigger: 'change' }
    ],
    location: [
        { required: true, message: '请输入场地位置', trigger: 'blur' }
    ],
    capacity: [
        { required: true, message: '请输入容纳人数', trigger: 'blur' }
    ],
    pricePerHour: [
        { required: true, message: '请输入每小时价格', trigger: 'blur' }
    ]
}

const venueFormRef = ref<FormInstance>()

// 加载场馆数据
const loadVenueData = async () => {
    loading.value = true
    try {
        const response = await axios.get('/api/venues', {
            params: {
                page: pagination.currentPage,
                size: pagination.pageSize,
                type: searchForm.venueType,
                status: searchForm.status
            }
        })

        if (response.data && response.data.code === 200) {
            venueList.value = response.data.data.records || []
            pagination.total = response.data.data.total || 0
        } else {
            venueList.value = []
            pagination.total = 0
        }
    } catch (error) {
        console.error('加载场馆数据失败:', error)
        ElMessage.error('加载场馆数据失败')
        venueList.value = []
        pagination.total = 0
    } finally {
        loading.value = false
    }
}

// 搜索场馆
const searchVenues = () => {
    pagination.currentPage = 1
    loadVenueData()
}

// 重置搜索条件
const resetSearch = () => {
    searchForm.venueType = ''
    searchForm.status = ''
    searchVenues()
}

// 处理每页显示数量变化
const handleSizeChange = (val: number) => {
    pagination.pageSize = val
    loadVenueData()
}

// 处理页码变化
const handleCurrentChange = (val: number) => {
    pagination.currentPage = val
    loadVenueData()
}

// 获取状态文本
const getStatusText = (status: string) => {
    const statusMap: Record<string, string> = {
        'NORMAL': '正常',
        'MAINTENANCE': '维护中',
        'SPECIAL': '特殊场地'
    }
    return statusMap[status] || status
}

// 获取状态类型
const getStatusType = (status: string) => {
    const typeMap: Record<string, string> = {
        'NORMAL': 'success',
        'MAINTENANCE': 'warning',
        'SPECIAL': 'info'
    }
    return typeMap[status] || ''
}

// 显示添加场地弹窗
const showAddVenueDialog = () => {
    dialogType.value = 'add'
    venueForm.id = null
    venueForm.name = ''
    venueForm.type = ''
    venueForm.location = ''
    venueForm.capacity = 10
    venueForm.pricePerHour = 50
    venueForm.peakHourPrice = 80
    venueForm.facilities = ''
    venueForm.description = ''
    venueForm.imageUrl = ''
    venueForm.status = 'NORMAL'
    venueDialogVisible.value = true
}

// 编辑场地
const editVenue = (venue: any) => {
    dialogType.value = 'edit'
    venueForm.id = venue.id
    venueForm.name = venue.name
    venueForm.type = venue.type
    venueForm.location = venue.location
    venueForm.capacity = venue.capacity
    venueForm.pricePerHour = venue.pricePerHour
    venueForm.peakHourPrice = venue.peakHourPrice
    venueForm.facilities = venue.facilities
    venueForm.description = venue.description
    venueForm.imageUrl = venue.imageUrl
    venueForm.status = venue.status
    venueDialogVisible.value = true
}

// 保存场地
const saveVenue = async () => {
    if (!venueFormRef.value) return
    
    await venueFormRef.value.validate(async (valid) => {
        if (valid) {
            try {
                const url = dialogType.value === 'add' ? '/api/venues' : `/api/venues/${venueForm.id}`
                const method = dialogType.value === 'add' ? 'post' : 'put'
                
                const response = await axios[method](url, venueForm)
                
                if (response.data && response.data.code === 200) {
                    ElMessage.success(dialogType.value === 'add' ? '添加场地成功' : '更新场地成功')
                    venueDialogVisible.value = false
                    loadVenueData()
                } else {
                    ElMessage.error(response.data.message || '操作失败')
                }
            } catch (error) {
                console.error('保存场地失败:', error)
                ElMessage.error('保存场地失败')
            }
        }
    })
}

// 确认删除场地
const confirmDeleteVenue = (venue: any) => {
    ElMessageBox.confirm(
        '确定要删除该场地吗？',
        '警告',
        {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
        }
    ).then(() => {
        deleteVenue(venue)
    })
}

// 删除场地
const deleteVenue = async (venue: any) => {
    try {
        const response = await axios.delete(`/api/venues/${venue.id}`)
        
        if (response.data && response.data.code === 200) {
            ElMessage.success('删除场地成功')
            loadVenueData()
        } else {
            ElMessage.error(response.data.message || '删除失败')
        }
    } catch (error) {
        console.error('删除场地失败:', error)
        ElMessage.error('删除场地失败')
    }
}

// 设置场地状态
const setVenueStatus = async (venue: any, status: string) => {
    try {
        const response = await axios.put(`/api/venues/${venue.id}/status`, { status })
        
        if (response.data && response.data.code === 200) {
            ElMessage.success('更新场地状态成功')
            loadVenueData()
        } else {
            ElMessage.error(response.data.message || '更新状态失败')
        }
    } catch (error) {
        console.error('更新场地状态失败:', error)
        ElMessage.error('更新场地状态失败')
    }
}

// 初始加载
onMounted(() => {
    loadVenueData()
})
</script>

<style scoped>
.admin-venues-container {
    padding: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.search-form {
    margin-bottom: 20px;
}

.pagination-container {
    margin-top: 20px;
    text-align: right;
}
</style> 