/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Page_SpecialArrangement_ } from './Page_SpecialArrangement_';
export type Result_Page_SpecialArrangement_ = {
    code?: number;
    data?: Page_SpecialArrangement_;
    msg?: string;
};

