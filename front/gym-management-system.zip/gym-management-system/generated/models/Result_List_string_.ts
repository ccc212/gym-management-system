/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Result_List_string_ = {
    code?: number;
    data?: Array<string>;
    msg?: string;
};

