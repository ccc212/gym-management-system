/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { UsageEntity } from './UsageEntity';
export type Page_UsageEntity_ = {
    current?: number;
    pages?: number;
    records?: Array<UsageEntity>;
    size?: number;
    total?: number;
};

