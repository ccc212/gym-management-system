/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionEquipmentRelationVO } from './CompetitionEquipmentRelationVO';
export type Result_List_CompetitionEquipmentRelationVO_ = {
    code?: number;
    data?: Array<CompetitionEquipmentRelationVO>;
    msg?: string;
};

