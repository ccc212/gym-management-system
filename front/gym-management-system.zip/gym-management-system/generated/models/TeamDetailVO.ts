/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { User } from './User';
export type TeamDetailVO = {
    createTime?: string;
    departId?: number;
    departName?: string;
    id?: number;
    leaderName?: string;
    leaderPhone?: string;
    members?: Array<User>;
    teamName?: string;
    updateTime?: string;
};

