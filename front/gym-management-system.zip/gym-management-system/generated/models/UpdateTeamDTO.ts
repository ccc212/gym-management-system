/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UpdateTeamDTO = {
    departId?: number;
    id?: number;
    leaderName?: string;
    leaderPhone?: string;
    memberIds?: Array<number>;
    teamName?: string;
};

