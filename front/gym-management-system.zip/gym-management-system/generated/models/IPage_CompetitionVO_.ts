/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionVO } from './CompetitionVO';
export type IPage_CompetitionVO_ = {
    current?: number;
    pages?: number;
    records?: Array<CompetitionVO>;
    size?: number;
    total?: number;
};

