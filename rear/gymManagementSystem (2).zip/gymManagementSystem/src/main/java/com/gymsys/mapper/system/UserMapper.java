package com.gymsys.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gymsys.entity.system.User;

public interface UserMapper extends BaseMapper<User> {
}
