package com.gymsys.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gymsys.entity.system.SysUserRole;

public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {
    
}
