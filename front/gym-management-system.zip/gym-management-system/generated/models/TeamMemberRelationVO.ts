/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type TeamMemberRelationVO = {
    createTime?: string;
    id?: number;
    name?: string;
    status?: number;
    teamId?: number;
    userId?: number;
    userNumber?: string;
};

