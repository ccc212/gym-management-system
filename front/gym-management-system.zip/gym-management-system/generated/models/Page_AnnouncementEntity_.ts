/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { AnnouncementEntity } from './AnnouncementEntity';
export type Page_AnnouncementEntity_ = {
    current?: number;
    pages?: number;
    records?: Array<AnnouncementEntity>;
    size?: number;
    total?: number;
};

