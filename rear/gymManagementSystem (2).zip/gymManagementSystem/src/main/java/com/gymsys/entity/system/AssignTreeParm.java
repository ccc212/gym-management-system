package com.gymsys.entity.system;

import lombok.Data;

@Data
public class AssignTreeParm {
    private Integer roleId;
    private Integer userId;
}
