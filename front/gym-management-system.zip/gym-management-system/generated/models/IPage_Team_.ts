/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Team } from './Team';
export type IPage_Team_ = {
    current?: number;
    pages?: number;
    records?: Array<Team>;
    size?: number;
    total?: number;
};

