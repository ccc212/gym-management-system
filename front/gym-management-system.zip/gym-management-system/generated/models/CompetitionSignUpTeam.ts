/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CompetitionSignUpTeam = {
    competitionId?: number;
    competitionItemId?: number;
    departId?: number;
    id?: number;
    leaderName?: string;
    leaderPhone?: string;
    rejectReason?: string;
    remark?: string;
    status?: number;
    teamId?: number;
    teamName?: string;
};

