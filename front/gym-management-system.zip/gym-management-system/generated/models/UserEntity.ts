/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UserEntity = {
    createdAt?: string;
    id?: number;
    password?: string;
    role?: string;
    updatedAt?: string;
    username?: string;
};

