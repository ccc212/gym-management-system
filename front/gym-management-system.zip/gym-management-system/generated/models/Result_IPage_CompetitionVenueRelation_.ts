/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IPage_CompetitionVenueRelation_ } from './IPage_CompetitionVenueRelation_';
export type Result_IPage_CompetitionVenueRelation_ = {
    code?: number;
    data?: IPage_CompetitionVenueRelation_;
    msg?: string;
};

