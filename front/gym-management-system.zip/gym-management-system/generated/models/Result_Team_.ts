/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Team } from './Team';
export type Result_Team_ = {
    code?: number;
    data?: Team;
    msg?: string;
};

