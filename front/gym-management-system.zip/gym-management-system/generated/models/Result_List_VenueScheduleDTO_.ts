/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { VenueScheduleDTO } from './VenueScheduleDTO';
export type Result_List_VenueScheduleDTO_ = {
    code?: number;
    data?: Array<VenueScheduleDTO>;
    msg?: string;
};

