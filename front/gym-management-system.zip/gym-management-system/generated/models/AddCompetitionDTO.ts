/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AddCompetitionDTO = {
    category?: number;
    competitionItemIds?: Array<number>;
    description?: string;
    endTime?: string;
    hoster?: string;
    isTeamCompetition?: number;
    maxSignUpNum?: number;
    name?: string;
    requirement?: string;
    signUpDeadline?: string;
    startTime?: string;
    teamMaxNum?: number;
    teamMinNum?: number;
    type?: number;
};

