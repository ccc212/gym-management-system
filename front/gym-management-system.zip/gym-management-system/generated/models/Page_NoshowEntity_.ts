/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { NoshowEntity } from './NoshowEntity';
export type Page_NoshowEntity_ = {
    current?: number;
    pages?: number;
    records?: Array<NoshowEntity>;
    size?: number;
    total?: number;
};

