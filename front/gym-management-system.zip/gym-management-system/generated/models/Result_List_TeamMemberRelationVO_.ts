/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TeamMemberRelationVO } from './TeamMemberRelationVO';
export type Result_List_TeamMemberRelationVO_ = {
    code?: number;
    data?: Array<TeamMemberRelationVO>;
    msg?: string;
};

