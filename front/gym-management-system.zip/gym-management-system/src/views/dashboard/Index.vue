<template>
    <div>
        欢迎访问海大体育馆管理系统
        
    </div>
</template>

<script setup lang="ts">
</script>

<style scoped>

</style>