/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type Equipment = {
    administrator?: string;
    createTime?: string;
    equipmentName?: string;
    id?: number;
    remainingQuantity?: number;
    repairReason?: string;
    repairTime?: string;
    setCreateTime?: string;
    setUpdateTime?: string;
    status?: number;
    type?: string;
    updateTime?: string;
};

