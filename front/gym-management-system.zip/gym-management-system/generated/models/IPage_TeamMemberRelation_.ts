/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TeamMemberRelation } from './TeamMemberRelation';
export type IPage_TeamMemberRelation_ = {
    current?: number;
    pages?: number;
    records?: Array<TeamMemberRelation>;
    size?: number;
    total?: number;
};

