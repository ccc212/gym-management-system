/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AddCompetitionVenueRelationDTO = {
    competitionId?: number;
    endTime?: string;
    num?: number;
    phone?: string;
    responsibleName?: string;
    startTime?: string;
    venueId?: number;
};

