/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IPage_CompetitionItem_ } from './IPage_CompetitionItem_';
export type Result_IPage_CompetitionItem_ = {
    code?: number;
    data?: IPage_CompetitionItem_;
    msg?: string;
};

