/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionEquipmentRelation } from './CompetitionEquipmentRelation';
export type IPage_CompetitionEquipmentRelation_ = {
    current?: number;
    pages?: number;
    records?: Array<CompetitionEquipmentRelation>;
    size?: number;
    total?: number;
};

