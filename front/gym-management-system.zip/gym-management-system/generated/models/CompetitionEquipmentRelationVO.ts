/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CompetitionEquipmentRelationVO = {
    competitionId?: number;
    endTime?: string;
    equipmentId?: number;
    equipmentName?: string;
    id?: number;
    num?: number;
    startTime?: string;
    status?: number;
};

