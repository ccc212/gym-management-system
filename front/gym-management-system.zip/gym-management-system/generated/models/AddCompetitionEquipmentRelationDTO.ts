/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AddCompetitionEquipmentRelationDTO = {
    competitionId?: number;
    endTime?: string;
    equipmentId?: number;
    num?: number;
    startTime?: string;
};

