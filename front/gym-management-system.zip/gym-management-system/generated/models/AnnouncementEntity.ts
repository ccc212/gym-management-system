/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AnnouncementEntity = {
    active?: boolean;
    content?: string;
    createdAt?: string;
    expireTime?: string;
    id?: number;
    publishTime?: string;
    status?: string;
    title?: string;
    updatedAt?: string;
};

