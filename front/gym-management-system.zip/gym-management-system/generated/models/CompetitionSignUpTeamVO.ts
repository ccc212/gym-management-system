/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type CompetitionSignUpTeamVO = {
    competitionItem?: string;
    competitionName?: string;
    competitionStatus?: number;
    competitionType?: string;
    endTime?: string;
    id?: number;
    rejectReason?: string;
    signUpDeadline?: string;
    signUpStatus?: number;
    startTime?: string;
    teamName?: string;
};

