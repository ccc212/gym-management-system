/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TeamDetailVO } from './TeamDetailVO';
export type Result_TeamDetailVO_ = {
    code?: number;
    data?: TeamDetailVO;
    msg?: string;
};

