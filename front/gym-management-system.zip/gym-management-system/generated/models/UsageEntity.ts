/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UsageEntity = {
    cardNumber?: string;
    cost?: number;
    createdAt?: string;
    endTime?: string;
    id?: number;
    paid?: boolean;
    startTime?: string;
    updatedAt?: string;
    userId?: number;
    venueId?: number;
};

