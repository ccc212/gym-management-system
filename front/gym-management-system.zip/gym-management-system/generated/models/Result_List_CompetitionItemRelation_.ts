/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionItemRelation } from './CompetitionItemRelation';
export type Result_List_CompetitionItemRelation_ = {
    code?: number;
    data?: Array<CompetitionItemRelation>;
    msg?: string;
};

