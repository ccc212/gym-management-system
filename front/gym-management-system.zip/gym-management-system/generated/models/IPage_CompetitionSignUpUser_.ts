/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionSignUpUser } from './CompetitionSignUpUser';
export type IPage_CompetitionSignUpUser_ = {
    current?: number;
    pages?: number;
    records?: Array<CompetitionSignUpUser>;
    size?: number;
    total?: number;
};

