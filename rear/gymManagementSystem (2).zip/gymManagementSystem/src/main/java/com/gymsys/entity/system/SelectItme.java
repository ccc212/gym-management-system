package com.gymsys.entity.system;

import lombok.Data;

@Data
public class SelectItme {
    private Integer value;
    private String label;
}
