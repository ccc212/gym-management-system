/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionVenueRelation } from './CompetitionVenueRelation';
export type Result_List_CompetitionVenueRelation_ = {
    code?: number;
    data?: Array<CompetitionVenueRelation>;
    msg?: string;
};

