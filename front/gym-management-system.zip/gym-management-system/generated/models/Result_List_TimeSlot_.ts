/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { TimeSlot } from './TimeSlot';
export type Result_List_TimeSlot_ = {
    code?: number;
    data?: Array<TimeSlot>;
    msg?: string;
};

