/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AddCompetitionSignUpUserDTO = {
    competitionId?: number;
    competitionItemId?: number;
    departId?: number;
    email?: string;
    name?: string;
    phone?: string;
    remark?: string;
    sex?: string;
    userId?: number;
    userNumber?: string;
    userStuorfac?: string;
};

