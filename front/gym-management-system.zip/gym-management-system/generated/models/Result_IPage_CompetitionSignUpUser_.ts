/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IPage_CompetitionSignUpUser_ } from './IPage_CompetitionSignUpUser_';
export type Result_IPage_CompetitionSignUpUser_ = {
    code?: number;
    data?: IPage_CompetitionSignUpUser_;
    msg?: string;
};

