/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionSignUpUserVO } from './CompetitionSignUpUserVO';
export type Result_List_CompetitionSignUpUserVO_ = {
    code?: number;
    data?: Array<CompetitionSignUpUserVO>;
    msg?: string;
};

