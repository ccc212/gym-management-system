/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type SpecialArrangement = {
    createdAt?: string;
    date?: string;
    endTime?: string;
    id?: number;
    remarks?: string;
    startTime?: string;
    status?: string;
    updatedAt?: string;
    venueId?: number;
    venueName?: string;
    venueType?: string;
};

