/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IPage_CompetitionEquipmentRelation_ } from './IPage_CompetitionEquipmentRelation_';
export type Result_IPage_CompetitionEquipmentRelation_ = {
    code?: number;
    data?: IPage_CompetitionEquipmentRelation_;
    msg?: string;
};

