/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionVenueRelation } from './CompetitionVenueRelation';
export type IPage_CompetitionVenueRelation_ = {
    current?: number;
    pages?: number;
    records?: Array<CompetitionVenueRelation>;
    size?: number;
    total?: number;
};

