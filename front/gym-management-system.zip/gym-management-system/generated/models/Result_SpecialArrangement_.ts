/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SpecialArrangement } from './SpecialArrangement';
export type Result_SpecialArrangement_ = {
    code?: number;
    data?: SpecialArrangement;
    msg?: string;
};

