package com.gymsys.service.system;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gymsys.entity.system.Department;

public interface DepartmentService extends IService<Department> {
}
