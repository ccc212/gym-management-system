/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { SpecialArrangement } from './SpecialArrangement';
export type Page_SpecialArrangement_ = {
    current?: number;
    pages?: number;
    records?: Array<SpecialArrangement>;
    size?: number;
    total?: number;
};

