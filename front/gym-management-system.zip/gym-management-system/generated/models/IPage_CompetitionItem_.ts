/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionItem } from './CompetitionItem';
export type IPage_CompetitionItem_ = {
    current?: number;
    pages?: number;
    records?: Array<CompetitionItem>;
    size?: number;
    total?: number;
};

