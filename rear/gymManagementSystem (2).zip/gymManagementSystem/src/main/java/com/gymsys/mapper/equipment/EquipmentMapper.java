package com.gymsys.mapper.equipment;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gymsys.entity.equip.Equipment;

public interface EquipmentMapper extends BaseMapper<Equipment> {
    // 可自定义复杂SQL方法
}