/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type User = {
    age?: string;
    createTime?: string;
    departId?: number;
    email?: string;
    id?: number;
    name?: string;
    password?: string;
    phone?: string;
    roleId?: number;
    sectionId?: number;
    sex?: string;
    updateTime?: string;
    userNumber?: string;
    userType?: string;
};

