/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionVenueRelationVO } from './CompetitionVenueRelationVO';
export type Result_List_CompetitionVenueRelationVO_ = {
    code?: number;
    data?: Array<CompetitionVenueRelationVO>;
    msg?: string;
};

