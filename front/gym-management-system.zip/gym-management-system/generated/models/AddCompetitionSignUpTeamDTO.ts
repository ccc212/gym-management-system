/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type AddCompetitionSignUpTeamDTO = {
    competitionId?: number;
    competitionItemId?: number;
    departId?: number;
    leaderName?: string;
    leaderPhone?: string;
    remark?: string;
    teamId?: number;
    teamName?: string;
};

