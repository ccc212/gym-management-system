package com.gymsys.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gymsys.entity.system.SysUserDepart;

public interface SysUserDepartMapper extends BaseMapper<SysUserDepart> {
}
