/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { CompetitionSignUpTeam } from './CompetitionSignUpTeam';
export type IPage_CompetitionSignUpTeam_ = {
    current?: number;
    pages?: number;
    records?: Array<CompetitionSignUpTeam>;
    size?: number;
    total?: number;
};

