/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type UpdateCompetitionDTO = {
    category?: number;
    competitionItemIds?: Array<number>;
    description?: string;
    endTime?: string;
    hoster?: string;
    id?: number;
    isTeamCompetition?: number;
    maxSignUpNum?: number;
    name?: string;
    requirement?: string;
    signUpDeadline?: string;
    signUpNum?: number;
    startTime?: string;
    status?: number;
    teamMaxNum?: number;
    teamMinNum?: number;
    type?: number;
};

