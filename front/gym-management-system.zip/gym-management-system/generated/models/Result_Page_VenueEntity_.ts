/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { Page_VenueEntity_ } from './Page_VenueEntity_';
export type Result_Page_VenueEntity_ = {
    code?: number;
    data?: Page_VenueEntity_;
    msg?: string;
};

