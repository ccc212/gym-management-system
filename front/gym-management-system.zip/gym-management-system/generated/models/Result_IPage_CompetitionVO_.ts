/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IPage_CompetitionVO_ } from './IPage_CompetitionVO_';
export type Result_IPage_CompetitionVO_ = {
    code?: number;
    data?: IPage_CompetitionVO_;
    msg?: string;
};

