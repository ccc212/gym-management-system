package com.gymsys.mapper.system;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gymsys.entity.system.SysUserSection;

public interface SysUserSectionMapper extends BaseMapper<SysUserSection> {
}
