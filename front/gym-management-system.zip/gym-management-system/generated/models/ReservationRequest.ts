/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type ReservationRequest = {
    cardNumber?: string;
    endTime?: string;
    numberOfPeople?: number;
    remarks?: string;
    startTime?: string;
    userId?: number;
};

