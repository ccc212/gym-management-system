/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { IPage_CompetitionSignUpTeam_ } from './IPage_CompetitionSignUpTeam_';
export type Result_IPage_CompetitionSignUpTeam_ = {
    code?: number;
    data?: IPage_CompetitionSignUpTeam_;
    msg?: string;
};

