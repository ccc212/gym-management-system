/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
export type VenueEntity = {
    capacity?: number;
    createdAt?: string;
    description?: string;
    id?: number;
    isAvailable?: boolean;
    location?: string;
    name?: string;
    pricePerHour?: number;
    status?: string;
    type?: string;
    updatedAt?: string;
};

