/* generated using openapi-typescript-codegen -- do not edit */
/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */
import type { ReservationEntity } from './ReservationEntity';
export type Page_ReservationEntity_ = {
    current?: number;
    pages?: number;
    records?: Array<ReservationEntity>;
    size?: number;
    total?: number;
};

